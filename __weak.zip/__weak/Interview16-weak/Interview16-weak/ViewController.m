//
//  ViewController.m
//  Interview16-weak
//
//  Created by MJ Lee on 2018/7/1.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"
#import "MJPerson.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // ARC是LLVM编译器和Runtime系统相互协作的一个结果
    
    __strong MJPerson *person1;
//    __weak MJPerson *person1;
//    __unsafe_unretained MJPerson *person1;
    
    NSLog(@"111");
    {
        //什么都不加，默认强指针，就相当于加一个__strong
        MJPerson *person = [[MJPerson alloc] init];
        
        person1 = person;
    }
    NSLog(@"222");

    NSLog(@"%p",person1);
    NSLog(@"%@",person1);
}

@end
